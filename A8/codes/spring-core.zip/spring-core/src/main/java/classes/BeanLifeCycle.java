package classes;

public class BeanLifeCycle {
	public void postConstruct() {
		System.out.println("Invoked after creation");
	}
	public void preDestroy() {
		System.out.println("Invoked before destruction");
	}
	public void test() { 
		System.out.println("Test");
	}
}
