package drivers;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import config.AppConfig;
import javabeans.Demo;

public class DemoDriver {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		Demo demo = context.getBean(Demo.class);

		// prints same reference if scope is singleton
		// prints different references if scope is prototype
		System.out.println(context.getBean(Demo.class));
		System.out.println(context.getBean(Demo.class));
		System.out.println(context.getBean(Demo.class));
	}
}
