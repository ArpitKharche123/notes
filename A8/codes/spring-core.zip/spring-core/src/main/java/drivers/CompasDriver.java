package drivers;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import config.AppConfig;
import javabeans.Compas;

public class CompasDriver {
	public static void main(String[] args) {
		ApplicationContext context =
		new AnnotationConfigApplicationContext(AppConfig.class);

		Compas compas = context.getBean(Compas.class);
		
		compas.getRuler().measure();
	}
}
