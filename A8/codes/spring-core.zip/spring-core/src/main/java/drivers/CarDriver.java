package drivers;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import config.AppConfig;
import javabeans.Car;

public class CarDriver {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		Car car = context.getBean(Car.class);
		car.run();
		System.out.println(car.getModel());
		System.out.println(car.getBrand());
		System.out.println(car.getTyres());
		System.out.println(car.getPriceRange());
		
		System.out.println(car.getEngine().getCc());

	}
}
