package drivers;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import classes.BeanLifeCycle;

public class LifecycleDriver {
	public static void main(String[] args) {
		ConfigurableApplicationContext context=
				new ClassPathXmlApplicationContext("config.xml");
		
		BeanLifeCycle bean = context.getBean(BeanLifeCycle.class);
		bean.test();
		
		context.close();
		System.out.println("Destroyed");
	}
}
