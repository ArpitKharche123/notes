package javabeans;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
@Scope("prototype")
@Getter
@Setter
@PropertySource("classpath:car.properties")
public class Car {
	
	@Autowired
	private Engine engine;
	
	//Setter Injection
	//We must call this setter to do DI using setter
//	public void setEngine(Engine engine) {
//		this.engine = engine;
//	}
	
	
	//Constructor Injection
//	public Car(Engine engine) {
//		this.engine=engine;
//	}
	
	

	@Value("NA")
	private String model;
	private String brand;

	@Value("${car.tyres}")
	private List<String> tyres;

	@Value("#{${car.priceRange}}")
	private Map<String, String> priceRange;

	public void run() {
		System.out.println("Car is running");
	}



}
