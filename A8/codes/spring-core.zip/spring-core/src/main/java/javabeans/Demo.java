package javabeans;

//read only class
public class Demo {

}
