package javabeans;

public interface Ruler {
	void measure();
}
