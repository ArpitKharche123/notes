package javabeans;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary//used to specify the primary qualifying bean in case of multiple beans
public class SteelRuler implements Ruler {
	@Override
	public void measure() {
		System.out.println("Measuring by Steel Ruler");
	}
}
