package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import javabeans.Demo;

@Configuration
@ComponentScan(basePackages = { "javabeans" })
//or
//@ComponentScan(basePackageClasses ={Car.class})
public class AppConfig {
	@Bean
	@Scope("prototype")// n number of beans will be created!!
	public Demo getDemo() {
		return new Demo();
	}
}
