package edu.j2ee.e1_sb_db.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.j2ee.e1_sb_db.entities.Bank;

@Repository
public interface BankRepository extends JpaRepository<Bank, Integer> {

}
