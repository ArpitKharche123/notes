package edu.j2ee.e1_sb_db.services.implementations;

import java.util.List;

import org.springframework.stereotype.Service;

import edu.j2ee.e1_sb_db.dto.BankDto;
import edu.j2ee.e1_sb_db.entities.Bank;
import edu.j2ee.e1_sb_db.mappers.BankMapper;
import edu.j2ee.e1_sb_db.repositories.BankRepository;
import edu.j2ee.e1_sb_db.services.BankService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BankServiceImpl implements BankService {

	private final BankRepository bankRepository;
	private final BankMapper mapper;

	@Override
	public BankDto getBank(int id) {
		Bank bank = bankRepository.findById(id).orElseThrow(() -> new RuntimeException("Bank not found"));

		return mapper.toDto(bank);
	}

	@Override
	public List<BankDto> getAllBanks() {
		List<Bank> banks = bankRepository.findAll();
		return banks.stream().map(bank -> mapper.toDto(bank)).toList();
	}

	@Override
	public BankDto createBank(BankDto bankDto) {
		Bank newBank = bankRepository.save(mapper.toEntity(bankDto));
		return mapper.toDto(newBank);
	}

	@Override
	public BankDto updateBank(int id, BankDto bankDto) {
		// Fetching
		Bank existingBank = bankRepository.findById(id).orElseThrow(() -> new RuntimeException("Bank not found"));

		// Update
		existingBank.setName(bankDto.getName());
		existingBank.setIfscPrefix(bankDto.getIfscPrefix());
		existingBank.setType(bankDto.getType());

		Bank updatedBank = bankRepository.save(existingBank);

		return mapper.toDto(updatedBank);
	}

	@Override
	public void deleteBank(int id) {
		bankRepository.deleteById(id);
	}

	@Override
	public void deleteAllBanks() {
		bankRepository.deleteAll();
	}
}
