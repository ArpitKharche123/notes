package edu.j2ee.e1_sb_db.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BankDto {
	private String name;
	private String ifscPrefix;
	private String type;
}
