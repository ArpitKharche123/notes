package edu.j2ee.e1_sb_db.services;

import java.util.List;

import edu.j2ee.e1_sb_db.dto.BankDto;

public interface BankService {
	// Abstract Service methods:
	public BankDto getBank(int id);

	public List<BankDto> getAllBanks();

	public BankDto createBank(BankDto bankDto);

	public BankDto updateBank(int id, BankDto bankDto);

	public void deleteBank(int id);

	public void deleteAllBanks();
}
