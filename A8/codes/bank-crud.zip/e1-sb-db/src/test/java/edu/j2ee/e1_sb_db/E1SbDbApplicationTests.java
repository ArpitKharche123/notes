package edu.j2ee.e1_sb_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E1SbDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
