package edu.j2ee.e1_sb_db.exceptionHandlers;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import edu.j2ee.e1_sb_db.dto.ErrorResponseDto;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ErrorResponseDto>
	resourceNotFoundHandler(
			ResourceNotFoundException e) {

		ErrorResponseDto dto = new ErrorResponseDto();
		dto.setStatus(HttpStatus.NOT_FOUND.value());
		dto.setError("NOT_FOUND");
		dto.setMessage(e.getMessage());
		dto.setTimeStamp(LocalDateTime.now());

		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(dto);
	}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponseDto>
	genericExceptionHandler(Exception e) {

		ErrorResponseDto dto = new ErrorResponseDto();
		dto.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		dto.setError("INTERNAL_SERVER_ERROR");
		dto.setMessage(e.getMessage());
		dto.setTimeStamp(LocalDateTime.now());

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(dto);
	}
}
