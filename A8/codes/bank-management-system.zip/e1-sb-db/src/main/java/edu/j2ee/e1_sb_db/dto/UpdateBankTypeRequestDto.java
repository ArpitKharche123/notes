package edu.j2ee.e1_sb_db.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateBankTypeRequestDto {
	private String type;
}
