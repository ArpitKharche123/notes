package Context;

import java.io.IOException;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/context")
public class DeveloperServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Fetching the ServletContext object
		ServletContext context = getServletContext();

		String companyName = context.getInitParameter("Company");
		String location = context.getInitParameter("Location");
		String services = context.getInitParameter("Services");

		resp.getWriter().print("<h1>Company Name:</h1>" + companyName 
				+ "<h1>Comany Location:</h1>" + location
				+ "<h1>Services Provided:</h1>" + services);
	}
}
