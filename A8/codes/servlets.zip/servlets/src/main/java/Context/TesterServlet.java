package Context;

import java.io.IOException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(value = "/config",
initParams = { 
		@WebInitParam(name = "testerRole",
					value = "SDET"),
		@WebInitParam(name = "requirements",
					value = "some product requirements") })
public class TesterServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Fetching ServletConfig object
		ServletConfig servletConfig = getServletConfig();

		String role = servletConfig.getInitParameter("testerRole");
		String requirements = servletConfig.getInitParameter("requirements");

		resp.getWriter().print("<h1>Role:</h1>" + role 
				+ "<h1>Requirement:</h1>" + requirements);

	}
}
