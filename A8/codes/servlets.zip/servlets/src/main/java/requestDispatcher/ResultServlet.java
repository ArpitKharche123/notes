package requestDispatcher;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//Fetching attributes forwarded from CalculateServlet
		Double omarks = (Double) req.getAttribute("omarks");
		Double tmarks = (Double) req.getAttribute("tmarks");
		Double percentage = (Double) req.getAttribute("percentage");
		
		resp.setContentType("text/html");
		resp.getWriter().print("<h1>Details: </h1>"
				+ "<h2>Obtained Marks: </h2>"+omarks
				+ "<h2>Total Marks: </h2>"+tmarks
				+ "<h2>Percentage: </h2>"+percentage);
	}
}
