package requestDispatcher;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/calculate")
public class CalculateServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Fetching form data
		double omarks = Double.parseDouble(req.getParameter("omarks"));
		double tmarks = Double.parseDouble(req.getParameter("tmarks"));
		double percentage = (omarks / tmarks) * 100;

		// Attaching data to request object
		req.setAttribute("omarks", omarks);
		req.setAttribute("tmarks", tmarks);
		req.setAttribute("percentage", percentage);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/result");
		dispatcher.forward(req, resp);
	}
}
