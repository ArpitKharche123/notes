package sessionmanagement;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cookie")
public class Cookies extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Cookie cookie= new Cookie("username","admin");
		Cookie cookie2= new Cookie("email", "admin@gmail.com");
		
		resp.addCookie(cookie);
		resp.addCookie(cookie2);
		
	resp.setContentType("text/html");
	resp.getWriter().print("<h1>Cookies created successfully</h1>"
				+ "<h2>"+cookie.getName() +"</h2>"
				+ "<h2>"+cookie.getValue() +"</h2>"
				);
	}
}
