package sessionmanagement;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/userlogin")
public class UserLoginServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Fetch form data
		String enteredUsername = req.getParameter("username");
		String enteredPassword = req.getParameter("password");

		// Fetching actual credentials
		ServletContext context = getServletContext();

		String actualUsername = context.getInitParameter("username");
		String actualPassword = context.getInitParameter("password");

		resp.setContentType("text/html");
		PrintWriter writer = resp.getWriter();

		if (enteredUsername.equals(actualUsername) 
				&& enteredPassword.equals(actualPassword)) {
			// Creating/ Starting a session
			HttpSession session = req.getSession();
			// Storing data into session
			session.setAttribute("username", actualUsername);

			writer.print("<h1>Login Successfull!</h1>" 
			+ "<h2>See the Dashboard Page: </h2>"
					+ "<a href='dashboard'>View Dashboard</a>");
		} else {
			RequestDispatcher dispatcher= req.
					getRequestDispatcher("userlogin.html");
			dispatcher.include(req, resp);
		}
	}
}
