package sessionmanagement;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/dashboard")
public class DashBoardServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session =req.getSession();
		resp.setContentType("text/html");
		PrintWriter writer =resp.getWriter();
		if(session!=null) {
			String username =(String)session.getAttribute("username");
			if(username!=null) {
				writer.print("<h1>Welcome </h1>"+ username+
						"<a href='logout'>Logout</a>");
			}else {
				resp.sendRedirect("userlogin.html");
			}
		}else {
			resp.sendRedirect("userlogin.html");
		}
	}
}
