package basics;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class Sevlet2 extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String email = req.getParameter("email");
		String phone = req.getParameter("number");

		PrintWriter writer = resp.getWriter();
		resp.setContentType("text/html");
		writer.print("<h1>Registration Successfull!!!</h1>" 
		+ "<h1>Username: </h1>" + username 
		+ "<h1>Email: </h1>"+ email
		+ "<h1>Phone Number: </h1>" + phone);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String email = req.getParameter("email");
		String phone = req.getParameter("number");

		PrintWriter writer = resp.getWriter();
		resp.setContentType("text/html");
		writer.print("<h1>Registration Successfull!!!</h1>" 
		+ "<h1>Username: </h1>" + username 
		+ "<h1>Email: </h1>"+ email
		+ "<h1>Phone Number: </h1>" + phone);
	}
}
