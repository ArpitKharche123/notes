package edu.j2ee.hotelcrud.dto;

import lombok.Setter;

@Setter
public class ResponseStructure<T> {
	private int statusCode;
	private String message;
	private T data;
}
