package edu.j2ee.branchcrud.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HotelRequestDTO {
	private String name;
	private double rating;
	private String type;
	private String address;
}
