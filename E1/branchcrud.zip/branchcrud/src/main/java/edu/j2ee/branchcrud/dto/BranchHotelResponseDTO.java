package edu.j2ee.branchcrud.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BranchHotelResponseDTO {
	private String name;
	private String city;
	private HotelRequestDTO dto;
}
