package edu.j2ee.branchcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BranchcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
