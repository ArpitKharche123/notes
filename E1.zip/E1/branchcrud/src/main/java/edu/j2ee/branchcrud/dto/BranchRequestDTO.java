package edu.j2ee.branchcrud.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BranchRequestDTO {
	private String name;
	private String city;
	private int hotelId;
}
