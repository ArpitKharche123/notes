package edu.j2ee.branchcrud.helpers;

import edu.j2ee.branchcrud.dto.BranchRequestDTO;
import edu.j2ee.branchcrud.entity.Branch;

public class Mapper {
	public static Branch toEntity(BranchRequestDTO dto) {
		return new Branch(dto.getName(), dto.getCity(), dto.getHotelId());
	}
}
