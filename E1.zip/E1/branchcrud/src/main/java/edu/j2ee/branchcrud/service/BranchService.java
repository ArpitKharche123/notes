package edu.j2ee.branchcrud.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import edu.j2ee.branchcrud.dto.BranchHotelResponseDTO;
import edu.j2ee.branchcrud.dto.BranchRequestDTO;
import edu.j2ee.branchcrud.dto.HotelRequestDTO;
import edu.j2ee.branchcrud.entity.Branch;
import edu.j2ee.branchcrud.helpers.Mapper;
import edu.j2ee.branchcrud.repository.BranchRepository;

@Service
public class BranchService {
	private BranchRepository repository;
	private RestTemplate restTemplate;
	
	public BranchService(BranchRepository repository, RestTemplate restTemplate) {
		this.repository = repository;
		this.restTemplate = restTemplate;
	}
	
	public Branch savebranch(BranchRequestDTO dto) {
		return repository.save(Mapper.toEntity(dto));
	}
	
	public List<BranchHotelResponseDTO> getByHotelId(int hotelId){
		//Fetching Hotel details
		HotelRequestDTO hotel= restTemplate.getForObject(
				"http://localhost:8080/hotel/"+hotelId,
				HotelRequestDTO.class);
		
		List<Branch> branches = repository.findByHotelId(hotelId);
		
		List<BranchHotelResponseDTO> response= new ArrayList<>();
		
		for(Branch branch:branches) {
			BranchHotelResponseDTO responseDto= new BranchHotelResponseDTO();
			responseDto.setName(branch.getName());
			responseDto.setCity(branch.getCity());
			responseDto.setDto(hotel);
			
			response.add(responseDto);
		}
		return response;
	}
	
}
