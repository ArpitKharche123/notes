package edu.j2ee.branchcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BranchcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BranchcrudApplication.class, args);
	}

}
